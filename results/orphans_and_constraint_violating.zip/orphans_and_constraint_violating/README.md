## About
These are the orphans and otherwise constraint-violating triples described in `report/report.pdf`. They are stored as Python 3.7 pickles of the form
```
{
    'out-orphans': set('<http://...>', ...),
    'in-orphans': set('<http://...>', ...),
}
```